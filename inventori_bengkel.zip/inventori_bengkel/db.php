<?php
$hos = '127.0.0.1';
$port = 3306;
$pangkalanData = 'inventori_bengkel';
$pengguna = 'root';
$kataLaluan = '';

$sambungan = new PDO(
    "mysql:host=$hos;port=$port;dbname=$pangkalanData;charset=utf8mb4",
    $pengguna,
    $kataLaluan,
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
