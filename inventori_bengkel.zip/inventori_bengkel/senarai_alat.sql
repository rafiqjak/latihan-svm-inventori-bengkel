CREATE TABLE IF NOT EXISTS peralatan (
    kod_alat VARCHAR(10) PRIMARY KEY,
    nama_alat VARCHAR(80) NOT NULL,
    kuantiti INT NOT NULL
);

INSERT INTO peralatan (kod_alat, nama_alat, kuantiti) VALUES
    ('A101', 'Multimeter digital', 4),
    ('A102', 'Pemotong wayar', 0),
    ('A103', 'Playar muncung tirus', 1),
    ('A104', 'Set pemutar skru', 6);
