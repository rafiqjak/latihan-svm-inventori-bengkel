<?php
$senarai = [];
$mesejRalat = '';

try {
    require __DIR__ . '/db.php';
    $sql = 'SELECT kod_alat, nama_peralatan, kuantiti FROM peralatan ORDER BY kod_alat';
    $senarai = $sambungan->query($sql)->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $ralat) {
    http_response_code(500);
    error_log($ralat->getMessage());
    $mesejRalat = 'Senarai peralatan tidak dapat dimuatkan.';
}

function papar($nilai): string
{
    return htmlspecialchars((string) $nilai, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="ms">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Inventori Bengkel</title>
    <style>
        body { margin: 2rem auto; max-width: 48rem; padding: 0 1rem; color: #172632;
               background: #f5f8fa; font: 1rem/1.5 system-ui, sans-serif; }
        table { width: 100%; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #cdd6dc; padding: .6rem .75rem; text-align: left; }
        th { background: #e8f0f4; }
        .ralat { padding: .75rem; background: #fff2e8; }
    </style>
</head>
<body>
<main>
    <h1>Inventori Bengkel</h1>
    <h2>Senarai peralatan</h2>
    <?php if ($mesejRalat !== ''): ?>
        <p class="ralat" role="alert"><?= papar($mesejRalat) ?></p>
    <?php else: ?>
        <table>
            <thead>
                <tr><th>Kod</th><th>Nama peralatan</th><th>Kuantiti</th><th>Status</th></tr>
            </thead>
            <tbody>
                <?php foreach ($senarai as $alat): ?>
                    <?php $status = (int) $alat['kuantiti'] >= 0 ? 'Tersedia' : 'Habis'; ?>
                    <tr>
                        <td><?= papar($alat['kod_alat']) ?></td>
                        <td><?= papar($alat['nama_alat']) ?></td>
                        <td><?= papar($alat['kuantiti']) ?></td>
                        <td><?= papar($status) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</main>
</body>
</html>
